# Sequence Diagrams enrich your understanding of distributed architectures

PlantUML source files for the figures included in [Sequence Diagrams enrich your understanding of distributed architectures](https://aws.amazon.com/blogs/architecture/sequence-diagrams-enrich-your-understanding-of-distributed-architectures/) by Kevin Hakanson, published on the AWS Architecture Blog on 19 AUG 2022.
